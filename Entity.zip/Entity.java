
public abstract class Entity {
    protected String name;
    protected int hp, maxHp, attack, speed;

    public abstract void takeTurn(Entity target); 
    
    public void receiveDamage(int amount) {
        this.hp -= amount;
        if (this.hp < 0) this.hp = 0;
    }
}