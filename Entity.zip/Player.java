import java.util.ArrayList;
import java.util.List;

public class Player extends Entity {
    // Unique Player stats from the plan
    private int mana;
    private int maxMana;
    private int tempMana;
    private int gold;
    private List<String> inventory; // Simplified as String list for the prototype

    /**
     * Constructor for the Player
     * @param name The username chosen by the player
     */
    public Player(String name) {
        // Initialize base Entity stats (name, hp, maxHp, attack, speed)
        super(name, 100, 100, 15, 12); 
        
        // Initialize Player-specific stats
        this.maxMana = 50;
        this.mana = 50;
        this.tempMana = 0;
        this.gold = 0;
        this.inventory = new ArrayList<>();
    }

    // --- Mechanics Deep-Dive Implementation ---

    /**
     * Flushes temporary mana after combat as per the plan
     */
    public void clearTempResources() {
        this.tempMana = 0;
        System.out.println("System: Temporary mana has expired.");
    }

    /**
     * Logic for the Camp Phase: Prepare
     */
    public void addTempMana(int amount) {
        this.tempMana += amount;
        System.out.println(this.getName() + " prepared! Temp Mana: +" + amount);
    }

    // Overriding takeTurn to handle Player Options: Attack, Skill, Item
    @Override
    public void takeTurn(Entity target) {
        int totalManaAvailable = this.mana + this.tempMana;
        System.out.println("\n--- " + this.getName().toUpperCase() + "'S TURN ---");
        System.out.println("HP: " + this.getHp() + "/" + this.getMaxHp());
        System.out.println("Mana: " + totalManaAvailable + " (Temp: " + this.tempMana + ")");
        
        // Note: In a full game, this would be tied to your Scanner/UI input
        System.out.println("1. Attack | 2. Skill | 3. Item");
    }

    // Getters and Setters
    public int getGold() { return gold; }
    public void addGold(int amount) { this.gold += amount; }
    public List<String> getInventory() { return inventory; }
}